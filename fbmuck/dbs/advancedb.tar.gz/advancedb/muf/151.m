: main me @ "wizard" flag? ;
